<?php
echo "PHP 7 orientado a objetos!";
echo "Pull";
?>
