<?php

echo date("d/m/Y H:i:s", 1509831034);

echo "<br>";

echo time();

?>