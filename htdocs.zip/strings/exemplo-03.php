<?php

$empresa = "Xbyte";

$empresa = str_replace("X", "J", $empresa);
$empresa = str_replace("y", "i", $empresa);

echo $empresa;

?>