<?php

$nome = "jhone henrique";

$nome  = strtoupper($nome);
echo $nome;

echo "<br>";

$nome = strtolower($nome);
echo $nome;

echo "<br>";

$nome = ucwords($nome);
echo $nome;

echo "<br>";

$nome = ucfirst($nome);
echo $nome;
 

?>