<?php

//Operador de String
$nome = "Xbyte";
echo $nome . " mais alguma coisa<br>";

//Operador composto
echo $nome .= " Treinamentos";

?>