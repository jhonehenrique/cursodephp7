<?php
//Oporeradores Aritimeticos

$a = 10;
$b = 2;

echo $a + $b;
echo "<br><hr>";
echo $a - $b;
echo "<br><hr>";
echo $a * $b;
echo "<br><hr>";
echo $a / $b;
echo "<br><hr>";
echo $a % $b;
echo "<br><hr>";
echo $a ** $b;


?>