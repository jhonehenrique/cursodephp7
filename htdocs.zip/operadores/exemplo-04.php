<?php
//Oporeradores Aritimeticos

$a = 55.0;
$b = 55;


var_dump($a > $b);
echo "<br><hr>";
var_dump($a < $b);
echo "<br><hr>";
var_dump($a == $b);
echo "<br><hr>";
var_dump($a === $b);
echo "<br><hr>";
var_dump($a !== $b);


?>