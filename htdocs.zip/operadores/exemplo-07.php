<?php

$a = 10;

//echo $a++;
//echo ++$a;
echo $a--;

echo "<b><hr>";

echo $a;

echo "<b><hr>";

?>