<?php

require_once('config.php');

echo session_id();

?>