<?php

$frutas = array("laranja", "abacaxi", "melancia");

echo "<pre>";
print_r($frutas);

?>