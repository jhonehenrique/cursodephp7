<?php

//NOVIDADE ARRAY DE CONSTANTE//

define("BANCO_DE_DADOS", [
	'127.0.0.1',
	'root',
	'password',
	'db'
	]);


echo "<pre>";
print_r(BANCO_DE_DADOS);

?>