<?php

$valorTotal = 0;

$valorTotal += 100;

$valorTotal += 25;

//Porcentagem
$valorTotal *= .9;

echo $valorTotal;

?>