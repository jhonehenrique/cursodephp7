<?php

$a = 35;
$b = 60;

//Novo do PHP7
var_dump($a <=> $b);


?>