<?php

$a = NULL;
$b = NULL;
$c = 10;

echo $a ?? $b ?? $c;


?>