<?php

$nome = "Xbyte";
$nome2 = 'Xbyte';

//Interpolação de Variaveis entre aspas "" e ''

 

?>