<?php

define("SERVIDOR", "127.0.0.1");

echo SERVIDOR;

?>