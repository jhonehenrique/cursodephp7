<?php

setlocale(LC_ALL, "pt_BR","pt_BR.UTF-8", "portuguese");

echo strftime("%A %B");

?>